# CPF LIFE research calculation audit

Public research edition, 5 November 2026. All money is SGD.

The calculations folder contains the original full-precision CSV and JSON outputs, a self-contained Python model and its detailed methodology. Figures are modelled scenarios using the public CPF reference case, not personalised quotations or promised returns. See calculations/README.md for assumptions and reproduction instructions.

The original research values and model logic are unchanged. Presentation authoring files are not included.
