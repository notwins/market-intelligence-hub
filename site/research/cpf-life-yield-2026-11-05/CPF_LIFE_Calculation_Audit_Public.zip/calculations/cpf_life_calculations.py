#!/usr/bin/env python3
"""Reproducible deterministic CPF LIFE Standard illustration; Python stdlib only.
All amounts SGD, end-month cashflows; annual rates are effective decimals.
The official quoted inputs are from the public CPF reference case. They are
illustrations, not guarantees that the modeled payouts will never change.
"""
import csv
import json
import math
from pathlib import Path

OUT = Path(__file__).resolve().parent
A55 = 220400
P65 = 330100
D = 1780
DEFER = 120
AGES = [65, 70, 75, 80, 81, 85, 90, 95, 100, 105]
RATES = [0.0, 0.025, 0.04]
QUOTES = [(50000, 82400, 490), (110200, 170100, 950),
          (150000, 227900, 1250), (220400, 330100, 1780),
          (300000, 445600, 2380), (440800, 650100, 3440)]


def logsumexp(values):
    if not values:
        return -math.inf
    top = max(values)
    return top + math.log(math.fsum(math.exp(v - top) for v in values))


def logexpm1(value):
    return value + math.log1p(-math.exp(-value)) if value > 50 else math.log(math.expm1(value))


def log_annuity(n, x):
    """Log of sum(exp(-x*t), t=1..n); x is monthly log growth."""
    if n == 0:
        return -math.inf
    if x == 0:
        return math.log(n)
    if x > 0:
        return math.log(-math.expm1(-n*x)) - logexpm1(x)
    return logexpm1(-n*x) - math.log(-math.expm1(x))


def solve_log_rate(log_pv_minus_cost):
    lo, hi = -1.0, 1.0
    for _ in range(20):
        if log_pv_minus_cost(lo) >= 0:
            break
        lo *= 2
    for _ in range(20):
        if log_pv_minus_cost(hi) <= 0:
            break
        hi *= 2
    if log_pv_minus_cost(lo) < 0 or log_pv_minus_cost(hi) > 0:
        raise ArithmeticError('IRR root was not bracketed')
    for _ in range(110):
        mid = (lo + hi) / 2
        if log_pv_minus_cost(mid) > 0:
            lo = mid
        else:
            hi = mid
    return math.expm1(12 * (lo + hi) / 2)


def irr_annuity(initial, monthly, n, terminal=0.0, defer=0):
    """Annualized IRR using closed-form annuity PV, including negative IRRs."""
    assert initial > 0 and monthly >= 0 and n >= 0 and terminal >= 0 and defer >= 0
    if n == 0:
        if terminal <= 0 or defer == 0:
            return None
        return math.expm1(math.log(terminal/initial)*12/defer)
    if monthly == 0 and terminal == 0:
        return None
    if monthly*n + terminal == initial:
        return 0.0
    def objective(x):
        parts = []
        if monthly:
            parts.append(math.log(monthly) + log_annuity(n, x))
        if terminal:
            parts.append(math.log(terminal) - n*x)
        return logsumexp(parts) - defer*x - math.log(initial)
    return solve_log_rate(objective)


def irr_explicit(initial, flows):
    """Independent PV implementation and secant/bisection root solver.
    flows is a list of (month, amount), with positive amounts only.
    Uses raw discounted cashflow summation (not the annuity formula).
    """
    flows = [(t, c) for t, c in flows if c > 0]
    if not flows or max(t for t, _ in flows) == 0:
        return None
    if math.fsum(c for _, c in flows) == initial:
        return 0.0
    def objective(x):
        return logsumexp([math.log(c) - t*x for t, c in flows]) - math.log(initial)
    lo, hi = -1.0, 1.0
    while objective(lo) < 0:
        lo *= 2
    while objective(hi) > 0:
        hi *= 2
    flo, fhi = objective(lo), objective(hi)
    # Safeguarded secant iterations converge without Newton or the annuity PV.
    for iteration in range(200):
        candidate = (lo*fhi-hi*flo)/(fhi-flo)
        if not lo+(hi-lo)*0.1 < candidate < hi-(hi-lo)*0.1:
            candidate = (lo+hi)/2
        fc = objective(candidate)
        if fc > 0:
            lo, flo = candidate, fc
        else:
            hi, fhi = candidate, fc
        if hi-lo < 2e-16:
            break
    return math.expm1(12*(lo+hi)/2)


def row(n, a55=A55, premium=P65, monthly=D):
    cumulative = monthly*n
    bequest = max(premium-cumulative, 0)
    total = cumulative+bequest
    return {
        'month': n, 'age': 65+n/12,
        'monthly_payout': 0 if n == 0 else monthly,
        'cumulative_payout': cumulative, 'bequest': bequest,
        'household_total': total,
        'household_nominal_gain_from65': total-premium,
        'household_nominal_gain_from55': total-a55,
        'income_nominal_gain_from65': cumulative-premium,
        'income_nominal_gain_from55': cumulative-a55,
        'irr65_income': irr_annuity(premium, monthly, n),
        'irr65_household': irr_annuity(premium, monthly, n, bequest),
        'irr55_income': irr_annuity(a55, monthly, n, defer=120),
        'irr55_household': irr_annuity(a55, monthly, n, bequest, 120),
    }


def annuity_pv(n, annual_rate, monthly=D):
    if annual_rate == 0:
        return monthly*n
    j = math.expm1(math.log1p(annual_rate)/12)
    return monthly*(-math.expm1(-n*math.log1p(j)))/j


def opportunity(n, annual_rate):
    b = max(P65-D*n, 0)
    pv_income = annuity_pv(n, annual_rate)
    pv_bequest = b*math.exp(-n*math.log1p(annual_rate)/12)
    pv_household = pv_income+pv_bequest
    factor10 = (1+annual_rate)**10
    return {
        'month': n, 'age': 65+n/12, 'scenario_annual_net_return': annual_rate,
        'pv65_income': pv_income, 'pv65_bequest': pv_bequest,
        'pv65_household': pv_household,
        'npv65_income': pv_income-P65,
        'npv65_household': pv_household-P65,
        'pv55_income': pv_income/factor10,
        'pv55_household': pv_household/factor10,
        'npv55_income': pv_income/factor10-A55,
        'npv55_household': pv_household/factor10-A55,
        'capital65_needed_for_same_income_through_age': pv_income,
        'capital65_needed_for_same_income_and_terminal_bequest': pv_household,
    }


def age_string(month, start=65):
    return f'{start+month//12} years {month%12} months'


def portfolio(annual_rate, months=480):
    j = math.expm1(math.log1p(annual_rate)/12)
    remaining = float(P65)
    cumulative = 0.0
    shortfall = 0.0
    records = [{'month': 0, 'age': 65.0, 'scenario_annual_net_return': annual_rate,
                'actual_withdrawal': 0.0, 'cumulative_withdrawals': 0.0,
                'remaining_balance': remaining, 'monthly_shortfall': 0.0,
                'cumulative_shortfall': 0.0, 'cumulative_withdrawals_plus_remaining': remaining}]
    first_shortfall = None
    for n in range(1, months+1):
        available = remaining*(1+j)
        paid = min(available, D)
        remaining = max(available-paid, 0)
        gap = D-paid
        cumulative += paid
        shortfall += gap
        if gap > 1e-9 and first_shortfall is None:
            first_shortfall = n
        records.append({'month': n, 'age': 65+n/12, 'scenario_annual_net_return': annual_rate,
                        'actual_withdrawal': paid, 'cumulative_withdrawals': cumulative,
                        'remaining_balance': remaining, 'monthly_shortfall': gap,
                        'cumulative_shortfall': shortfall,
                        'cumulative_withdrawals_plus_remaining': cumulative+remaining})
    theoretical = P65/D if j == 0 else -math.log1p(-P65*j/D)/math.log1p(j)
    summary = {
        'scenario_annual_net_return': annual_rate,
        'monthly_net_return': j,
        'continuous_formula_depletion_months': theoretical,
        'first_shortfall_month': first_shortfall,
        'first_shortfall_age': 65+first_shortfall/12,
        'first_shortfall_age_label': age_string(first_shortfall),
        'last_fully_funded_month': first_shortfall-1,
        'withdrawal_in_first_shortfall_month': records[first_shortfall]['actual_withdrawal'],
        'first_month_shortfall': records[first_shortfall]['monthly_shortfall'],
        'capital_for_perpetual_1780_monthly': None if j == 0 else D/j,
        'capital_for_perpetual_1780_monthly_status': 'infinite_at_zero_return' if j == 0 else 'finite',
    }
    return records, summary


def write_csv(name, records):
    with (OUT/name).open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def main():
    monthly = [row(n) for n in range(481)]
    review = [monthly[(age-65)*12] for age in AGES]
    opportunities = [opportunity((age-65)*12, r) for r in RATES for age in AGES]
    portfolio_rows, summaries = [], []
    for rate in RATES:
        records, summary = portfolio(rate)
        portfolio_rows += records
        summaries.append(summary)
    portfolio_review = [r for r in portfolio_rows if r['age'] in AGES]
    scale = []
    for capital55, premium65, payout in QUOTES:
        recovery = math.ceil(premium65/payout)
        scale.append({'capital55': capital55, 'premium65': premium65, 'monthly_payout65': payout,
                      'annual_payout': payout*12,
                      'annual_payout_over_premium': payout*12/premium65,
                      'ra_endpoint_cagr_10yr': math.expm1(math.log(premium65/capital55)/10),
                      'ra_endpoint_gain': premium65-capital55,
                      'premium_payout_recovery_month': recovery,
                      'premium_payout_recovery_age': 65+recovery/12,
                      'premium_payout_recovery_age_label': age_string(recovery)})
    marginal = []
    for age in AGES:
        n = (age-65)*12
        delta_b = max(650100-3440*n,0)-max(330100-1780*n,0)
        delta_c = 1660*n
        marginal.append({'month': n, 'age': age, 'delta_capital55': 220400,
                         'delta_premium65': 320000, 'delta_monthly_payout': 1660,
                         'delta_cumulative_payout': delta_c,
                         'delta_actual_bequest': delta_b,
                         'delta_household_total': delta_c+delta_b,
                         'delta_household_nominal_gain_from65': delta_c+delta_b-320000,
                         'marginal_irr65_income': irr_annuity(320000,1660,n),
                         'marginal_irr65_household': irr_annuity(320000,1660,n,delta_b),
                         'marginal_irr55_income': irr_annuity(220400,1660,n,defer=120),
                         'marginal_irr55_household': irr_annuity(220400,1660,n,delta_b,120)})
    inflation = [{'age': age, 'years_after65': age-65, 'annual_cpi_scenario': rate,
                  'nominal_monthly_payout': D, 'monthly_purchasing_power_in_age65_sgd': D/(1+rate)**(age-65),
                  'purchasing_power_loss_fraction': 1-(1+rate)**(-(age-65))}
                 for age in [85,95] for rate in [0.02,0.03]]
    max_error = 0.0
    validations = []
    for n in sorted(set([(age-65)*12 for age in AGES]+[1,123,124,185,186,187,189,193])):
        for initial, defer, origin in [(A55,120,'55'),(P65,0,'65')]:
            for household in [False,True]:
                terminal = max(P65-D*n,0) if household else 0
                direct = irr_annuity(initial,D,n,terminal,defer)
                flows = [(defer+t,D) for t in range(1,n+1)]
                if terminal:
                    flows.append((defer+n,terminal))
                alternate = irr_explicit(initial,flows)
                if direct is None or alternate is None:
                    assert direct is None and alternate is None
                    error = 0.0
                else:
                    error = abs(direct-alternate)
                    assert error < 5e-13, (n,origin,household,direct,alternate,error)
                max_error = max(max_error,error)
                validations.append({'month':n,'origin_age':int(origin),'household':household,
                                    'annuity_irr':direct,'explicit_irr':alternate,'absolute_error':error})
    assert monthly[180]['cumulative_payout'] == 320400
    assert monthly[180]['bequest'] == 9700
    assert monthly[192]['household_nominal_gain_from65'] == 11660
    assert monthly[185]['bequest'] == 800 and monthly[186]['bequest'] == 0
    assert all(r['irr65_household'] == 0.0 for r in monthly[1:186])
    assert [s['first_shortfall_month'] for s in summaries] == [186,234,286]
    # Cross-check uncapped portfolio balances against closed form before depletion.
    balance_max_error = 0.0
    for record in portfolio_rows:
        n, r = record['month'], record['scenario_annual_net_return']
        j = math.expm1(math.log1p(r)/12)
        closed = P65-D*n if j == 0 else P65*(1+j)**n-D*math.expm1(n*math.log1p(j))/j
        expected = max(closed,0)
        balance_max_error = max(balance_max_error,abs(expected-record['remaining_balance']))
        assert abs(expected-record['remaining_balance']) < 1e-7
    core = {
        'ra_gain55to65': P65-A55,
        'ra_endpoint_cagr_10yr': math.expm1(math.log(P65/A55)/10),
        'annual_payout': D*12,
        'annual_payout_over_premium': D*12/P65,
        'perpetuity_net_effective_annual_hurdle': math.expm1(12*math.log1p(D/P65)),
        'income_recovers_age55_capital_month': math.ceil(A55/D),
        'income_recovers_age55_capital_age': 65+math.ceil(A55/D)/12,
        'income_recovers_age55_capital_age_label': age_string(math.ceil(A55/D)),
        'income_recovers_premium_month': math.ceil(P65/D),
        'income_recovers_premium_age': 65+math.ceil(P65/D)/12,
        'income_recovers_premium_age_label': age_string(math.ceil(P65/D)),
        'marginal_frs_ers_annual_payout_yield': 1660*12/320000,
        'marginal_frs_ers_income_recovery_month': math.ceil(320000/1660),
    }
    result = {
        'metadata': {
            'model': 'Constant-payout CPF LIFE Standard deterministic illustration',
            'currency': 'SGD', 'precision': 'Unrounded IEEE-754 Python double outputs; monetary anchors use exact integers where possible',
            'source_quote_page': 'https://www.cpf.gov.sg/service/article/how-much-cpf-payouts-can-i-get-every-month',
            'source_quote_verified_by_parent': '2026-06-16 page used by research parent',
            'first_payout': 'End of month1 after65; none at month0',
            'household_definition': 'Cumulative payouts plus one terminal bequest; no payout reinvestment',
            'bequest_definition': 'Remaining unpaid premium max(premium - cumulative payouts, 0); no pooled interest in bequest',
            'irr55_definition': 'Initial age55capital only, 120 zero-payment months, monthly payouts plus optional terminal bequest; age65premium is not a second outflow',
            'irr65_definition': 'Initial age65premium, then monthly payouts plus optional terminal bequest',
            'irr_at_zero_duration': 'Undefined for age65 origin at month0; represented null',
            'rates_unit': 'Effective annual decimal; multiply by100 for percent',
            'opportunity_scenarios': '0%,2.5%,4% are deterministic net discount/portfolio return scenarios, all SGD; no later capital, reinvestment of withdrawals, additional fees or taxes modeled',
            'cpf_rate_scope': '2.5% OA reference and4% RA reference do not mean CPF LIFE earns an investment return at those rates or that RA is an accessible alternative account; 4% RA floor only as officially announced',
            'finite_funding_scope': 'PV of the modeled finite payment stream at stated smooth net return; not an annuity product quote or mortality pricing',
            'limitations': ['Payouts assumed unchanged for illustration; actual estimates/payouts may be adjusted.', 'No mortality weighting, expected return, risk adjustment, inflation adjustment of nominal IRRs, tax relief, liquidity valuation or future capital flows.', 'Do not apply Standard bequest formula to Basic. No invented Basic or Escalating quotes.', 'No age70premium is known here; age70household IRR and full deferral comparison are intentionally absent.'],
        },
        'inputs': {'capital55':A55,'premium65':P65,'monthly_payout':D,'payout_start_age':65,'deferral_months':120,'horizon_age':105},
        'core': core, 'review_rows': review, 'monthly_rows': monthly,
        'opportunity_rows': opportunities, 'portfolio_review_rows': portfolio_review,
        'portfolio_summaries': summaries, 'capital_scale_rows': scale,
        'marginal_rows': marginal, 'inflation_rows': inflation,
        'defer_income_only': {'start65_monthly':1780,'start70_monthly':2380,'foregone_months':60,'foregone_income':106800,'monthly_increment':600,'catchup_months_after70':178,'catchup_age':70+178/12,'catchup_age_label':'84 years 10 months','scope':'Undiscounted income-only catch-up using the two supplied official fixed payout illustrations; excludes bequests, changed premium and opportunity cost.'},
        'validation': {'independent_irr_cases':len(validations),'max_absolute_annual_irr_difference':max_error,'max_portfolio_closed_form_balance_difference_sgd':balance_max_error,'passed':True}
    }
    (OUT/'results.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    for name, records in [('monthly_cashflows.csv',monthly),('review_metrics.csv',review),('opportunity_cost.csv',opportunities),('portfolio_monthly.csv',portfolio_rows),('portfolio_review.csv',portfolio_review),('capital_scale.csv',scale),('marginal_frs_ers.csv',marginal),('inflation.csv',inflation),('irr_crosscheck.csv',validations)]:
        write_csv(name,records)
    rounded = {
        'note': 'Presentation values intentionally rounded; source results.json retains full machine precision.',
        'core_percent_4dp': {k:round(v*100,4) for k,v in core.items() if 'cagr' in k or 'yield' in k or 'hurdle' in k or k=='annual_payout_over_premium'},
        'review_rows': [{**{k:r[k] for k in ['age','month','cumulative_payout','bequest','household_total','household_nominal_gain_from65','household_nominal_gain_from55']}, **{k+'_pct':None if r[k] is None else round(r[k]*100,4) for k in ['irr65_income','irr65_household','irr55_income','irr55_household']}} for r in review],
        'portfolio_summaries': summaries,
        'inflation_rows': [{**r,'monthly_purchasing_power_in_age65_sgd':round(r['monthly_purchasing_power_in_age65_sgd'],2),'purchasing_power_loss_pct':round(r['purchasing_power_loss_fraction']*100,2)} for r in inflation],
    }
    (OUT/'presentation_values.json').write_text(json.dumps(rounded,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'core':core,'review_rows':rounded['review_rows'],'portfolio_summaries':summaries,'inflation':rounded['inflation_rows'],'validation':result['validation']},indent=2))


if __name__ == '__main__':
    main()
