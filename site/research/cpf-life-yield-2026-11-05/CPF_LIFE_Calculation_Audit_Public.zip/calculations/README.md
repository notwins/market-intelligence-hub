# CPF LIFE calculation audit

This folder reproduces the numerical illustrations used in the CPF LIFE yield research. All monetary amounts are **Singapore dollars (SGD)**. Results describe specified cash flows and survival horizons; they are not personalised quotations or mortality-weighted expected returns.

## Reproduce

Python 3 and its standard library are sufficient. Run from this folder:

```bash
python3 cpf_life_calculations.py
```

The script regenerates the JSON and CSV files below in its own directory and runs the embedded numerical checks. No downloaded market data or external packages are required.

## Files

| File | Purpose |
| --- | --- |
| `cpf_life_calculations.py` | Model, formulas, two independent IRR solvers and validation checks. |
| `results.json` | Full calculation results, inputs, definitions, limitations and validation summary. |
| `presentation_values.json` | Selected values rounded for display, including percentage-form IRRs. |
| `monthly_cashflows.csv` | Monthly CPF cash flows and four IRRs, from age 65 to 105. |
| `review_metrics.csv` | The same metrics at selected review ages. |
| `opportunity_cost.csv` | Discounted income, refund and NPV; finite funding requirements. |
| `portfolio_monthly.csv` | Monthly matching-withdrawal portfolio balances and shortfalls. |
| `portfolio_review.csv` | Portfolio outcomes at selected review ages. |
| `capital_scale.csv` | Metrics for the six supplied official capital/payout illustrations. |
| `marginal_frs_ers.csv` | Incremental FRS-to-ERS cash flows, using the actual difference between the two refund schedules. |
| `inflation.csv` | Purchasing power of the fixed payout under illustrative inflation rates. |
| `irr_crosscheck.csv` | Primary and independent IRR results for 72 selected cases. |

Raw JSON and CSV retain unrounded IEEE-754 floating-point results; they do not claim infinite mathematical precision. Integer cash-flow anchors are exact where possible. Rates are effective annual **decimals** unless a column explicitly says `pct`; multiply decimals by 100 for percentages. Presentation rounding is separate from calculation. Extra calculated digits do not increase the precision of the underlying official illustrative inputs. Undefined IRRs appear as JSON `null` or blank CSV fields.

## Official reference inputs

The main illustration uses a male member turning 55 in 2026: S$220,400 at age 55, an estimated S$330,100 at age 65, and S$1,780 monthly under the Standard Plan. The research used the CPF Board reference dated 16 June 2026:

<https://www.cpf.gov.sg/service/article/how-much-cpf-payouts-can-i-get-every-month>

These are quoted endpoints and an illustrated payout, not a new forecast or a guarantee that payouts cannot change. The age-55-to-65 CAGR is inferred from those endpoints; it is not a claim that every dollar receives one uniform annual credited rate.

## Timing, refund and returns

- Month 0 is age 65 with no payout. S$1,780 is paid at each month end, beginning one month after age 65. Age 80 therefore includes 180 payments. No later contributions, payout reinvestment or additional CPF balances are included.
- After month `n`, cumulative payouts are `C = 1780 * n`. The modelled Standard Plan premium refund is `B = max(330100 - C, 0)`. Pooled interest is not added to this refund. A household-return calculation includes **one** terminal refund at the assumed death horizon. It is neither a liquid surrender value nor a separate extra capital account.
- `C + B` measures cumulative payouts plus the terminal refund, not wealth still held at the review age. Before premium depletion, that nominal total equals the premium; income continues after the refund reaches zero.
- **IRR from 65:** one initial S$330,100 outflow, followed by the monthly payouts. **IRR from 55:** one initial S$220,400 outflow, 120 months to age 65, then the first payout in month 121. The transfer of S$330,100 at 65 is internal and is not deducted again.
- Each starting date has an income-only IRR and an income-plus-refund household IRR. Monthly IRR is annualised as `(1 + monthly_IRR)^12 - 1`. At age 65 there is no elapsed time for an age-65 IRR; no-income cases also have no defined income IRR.
- Annual payout divided by premium is an income ratio, not investment return. The perpetual funding hurdle assumes a smooth net return sufficient to pay the monthly income while keeping the initial principal intact.

## Scenario scope and limitations

The 0%, 2.5% and 4% comparisons are constant effective annual **net** SGD discount/portfolio-return scenarios, converted to monthly growth. Portfolios grow first and then withdraw the monthly income, stopping at zero; the first partial payment is the first shortfall. No further fees, taxes, FX movements, later capital or reinvestment of withdrawn income are modelled. The 2.5% OA and 4% RA references do not make those accounts freely accessible substitute investments or imply those returns within CPF LIFE. No indefinite CPF rate guarantee is assumed.

Finite funding amounts are present values through the selected horizon, not insurer annuity quotations. There is no mortality weighting, sequence-of-returns risk, liquidity valuation or risk adjustment. Nominal IRRs exclude inflation; the separate 2% and 3% inflation examples are illustrative assumptions. The Standard refund formula must not be applied to the Basic Plan. No Basic/Escalating quote or age-70 premium is invented. The limited 65-versus-70 catch-up calculation uses only the supplied fixed income quotations and is undiscounted; it is not a household-return comparison.

The stored validation reports 72 independent IRR cross-checks, with maximum annual-rate difference about `1.09e-15`, and a maximum portfolio closed-form balance difference below S$0.00000001. These checks establish numerical consistency within this stated model, not the certainty of its future assumptions.
